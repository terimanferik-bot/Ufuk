package com.ultra.downloadmanager.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverters
import com.ultra.downloadmanager.data.database.Converters
import java.util.*

@Entity(tableName = "downloads")
@TypeConverters(Converters::class)
data class DownloadItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val url: String,
    val fileName: String,
    val filePath: String,
    val fileSize: Long = 0,
    val downloadedBytes: Long = 0,
    val status: DownloadStatus = DownloadStatus.PENDING,
    val priority: DownloadPriority = DownloadPriority.NORMAL,
    val connectionCount: Int = 8,
    val speed: Long = 0,
    val estimatedTimeRemaining: Long = 0,
    val createdAt: Date = Date(),
    val updatedAt: Date = Date(),
    val completedAt: Date? = null,
    val errorMessage: String? = null,
    val headers: Map<String, String> = emptyMap(),
    val tags: List<String> = emptyList(),
    val category: String = "Other",
    val mimeType: String = "",
    val checksum: String? = null,
    val isPaused: Boolean = false,
    val isResumable: Boolean = true,
    val retryCount: Int = 0,
    val maxRetries: Int = 3
) {
    val progress: Int
        get() = if (fileSize > 0) ((downloadedBytes * 100) / fileSize).toInt() else 0
    
    val isCompleted: Boolean
        get() = status == DownloadStatus.COMPLETED
    
    val isFailed: Boolean
        get() = status == DownloadStatus.FAILED
    
    val isActive: Boolean
        get() = status == DownloadStatus.DOWNLOADING || status == DownloadStatus.PAUSED
}

enum class DownloadStatus {
    PENDING,
    DOWNLOADING,
    PAUSED,
    COMPLETED,
    FAILED,
    CANCELLED,
    QUEUED
}

enum class DownloadPriority {
    LOW,
    NORMAL,
    HIGH,
    URGENT
}