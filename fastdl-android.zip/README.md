# FastDownloader - Complete Source + GitHub Actions Build System

## Özellikler
- Parçalı (multi-thread) indirme
- Otomatik hız optimizasyonu
- Yeniden bağlanma / hata kurtarma
- Wi-Fi veya mobil ağ algılama
- SHA256 doğrulama
- Proxy/VPN uyumluluğu

## GitHub Actions ile otomatik APK oluşturma
1. ZIP dosyasını çıkar ve projenin tamamını GitHub’a yükle.
2. Repo > Settings > Secrets > Actions kısmına şu değerleri ekle (imzalı APK istiyorsan):
   - KEYSTORE_BASE64
   - KEYSTORE_PASSWORD
   - KEY_ALIAS
   - KEY_PASSWORD
3. Actions sekmesinden `Android CI - build release APK` çalıştır.
4. Build tamamlanınca "Artifacts" kısmından imzalı APK’yı indir.

## Yerel derleme (Android Studio)
Android Studio ile projeyi aç → Build menüsünden "Build APK(s)" seçeneğini çalıştır.

## Ek Notlar
- GitHub Actions sürümü Java 17 kullanır.
- Workflow dosyası: `.github/workflows/android-build.yml`
- Derleme çıktısı: `app/build/outputs/apk/release/`
