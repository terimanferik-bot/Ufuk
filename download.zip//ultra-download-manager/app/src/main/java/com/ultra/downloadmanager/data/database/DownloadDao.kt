package com.ultra.downloadmanager.data.database

import androidx.lifecycle.LiveData
import androidx.room.*
import com.ultra.downloadmanager.data.models.DownloadItem
import com.ultra.downloadmanager.data.models.DownloadStatus
import kotlinx.coroutines.flow.Flow

@Dao
interface DownloadDao {
    
    @Query("SELECT * FROM downloads ORDER BY createdAt DESC")
    fun getAllDownloads(): Flow<List<DownloadItem>>
    
    @Query("SELECT * FROM downloads WHERE status = :status ORDER BY priority DESC, createdAt DESC")
    fun getDownloadsByStatus(status: DownloadStatus): Flow<List<DownloadItem>>
    
    @Query("SELECT * FROM downloads WHERE status IN (:statuses) ORDER BY priority DESC, createdAt DESC")
    fun getDownloadsByStatuses(statuses: List<DownloadStatus>): Flow<List<DownloadItem>>
    
    @Query("SELECT * FROM downloads WHERE id = :id")
    suspend fun getDownloadById(id: Long): DownloadItem?
    
    @Query("SELECT * FROM downloads WHERE url = :url")
    suspend fun getDownloadByUrl(url: String): DownloadItem?
    
    @Query("SELECT * FROM downloads WHERE category = :category ORDER BY createdAt DESC")
    fun getDownloadsByCategory(category: String): Flow<List<DownloadItem>>
    
    @Query("SELECT * FROM downloads WHERE fileName LIKE '%' || :query || '%' OR url LIKE '%' || :query || '%' ORDER BY createdAt DESC")
    fun searchDownloads(query: String): Flow<List<DownloadItem>>
    
    @Query("SELECT COUNT(*) FROM downloads WHERE status = :status")
    suspend fun getCountByStatus(status: DownloadStatus): Int
    
    @Query("SELECT SUM(fileSize) FROM downloads WHERE status = :status")
    suspend fun getTotalSizeByStatus(status: DownloadStatus): Long?
    
    @Query("SELECT SUM(downloadedBytes) FROM downloads WHERE status = :status")
    suspend fun getTotalDownloadedByStatus(status: DownloadStatus): Long?
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDownload(download: DownloadItem): Long
    
    @Update
    suspend fun updateDownload(download: DownloadItem)
    
    @Query("UPDATE downloads SET status = :status, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateDownloadStatus(id: Long, status: DownloadStatus, updatedAt: Long)
    
    @Query("UPDATE downloads SET downloadedBytes = :downloadedBytes, speed = :speed, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateDownloadProgress(id: Long, downloadedBytes: Long, speed: Long, updatedAt: Long)
    
    @Query("UPDATE downloads SET isPaused = :isPaused, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateDownloadPauseState(id: Long, isPaused: Boolean, updatedAt: Long)
    
    @Query("UPDATE downloads SET retryCount = retryCount + 1, updatedAt = :updatedAt WHERE id = :id")
    suspend fun incrementRetryCount(id: Long, updatedAt: Long)
    
    @Delete
    suspend fun deleteDownload(download: DownloadItem)
    
    @Query("DELETE FROM downloads WHERE id = :id")
    suspend fun deleteDownloadById(id: Long)
    
    @Query("DELETE FROM downloads WHERE status = :status")
    suspend fun deleteDownloadsByStatus(status: DownloadStatus)
    
    @Query("DELETE FROM downloads WHERE status IN (:statuses)")
    suspend fun deleteDownloadsByStatuses(statuses: List<DownloadStatus>)
    
    @Query("SELECT COUNT(*) FROM downloads")
    suspend fun getTotalDownloadCount(): Int
    
    @Query("SELECT DISTINCT category FROM downloads")
    suspend fun getAllCategories(): List<String>
    
    @Query("UPDATE downloads SET priority = :priority, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateDownloadPriority(id: Long, priority: Int, updatedAt: Long)
}