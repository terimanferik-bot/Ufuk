# Ultra Download Manager

Ultra Download Manager, Internet Download Manager'dan daha üstün, gelişmiş ve hızlı bir Android indirme yöneticisidir. Çoklu bağlantı teknolojisi, akıllı hız optimizasyonu ve modern kullanıcı arayüzü ile geleneksel indirme yöneticilerinin ötesine geçer.

## Özellikler

### Temel Özellikler
- **Çoklu Bağlantı Desteği** (32'e kadar eşzamanlı bağlantı)
- **Akıllı Hız Optimizasyonu** (500%'e kadar hız artışı)
- **Kaldığı Yerden Devam Etme** (Her türlü kesintiye karşı)
- **Toplu İndirme Yönetimi** (Kuyruk sistemi)
- **Zamanlanmış İndirmeler** (Otomatik başlatma)
- **Otomatik Yeniden Deneme** (Üstel geri çekilme algoritması)

### Gelişmiş Özellikler
- **Video İndirme** (1000+ web sitesinden)
- **Torrent Desteği** (Magnet link işleme)
- **Tarayıcı Entegrasyonu** (Chrome, Firefox, Edge)
- **Akıllı Dosya Sınıflandırması** (Otomatik kategorizasyon)
- **Yinelenen İndirme Tespiti**
- **Hız Sınırlayıcı** (Bant genişliği yönetimi)
- **İndirme Öncelik Sistemi**

### Dosya Yönetimi
- **Dahili Dosya Yöneticisi**
- **Sıkıştırma/Çıkarma** (ZIP, RAR, 7Z)
- **Medya Oynatıcı** (Önizleme için)
- **WiFi Direct Paylaşım**
- **Bulut Depolama Entegrasyonu**
- **FTP/SFTP Desteği**

### Güvenlik ve Gizlilik
- **VPN Entegrasyonu**
- **Kötü Yazılım Taraması**
- **Şifre Koruması**
- **Şifreli Depolama**
- **Anonim İndirme Modu**

## Teknik Özellikler

### Mimarisi
- **MVVM Mimarisi** (Clean Architecture)
- **Repository Pattern**
- **Dependency Injection** (Hilt/Dagger)
- **Coroutines** (Asenkron işlemler)
- **Flow** (Reaktif programlama)

### Teknoloji Yığını
- **Minimum SDK**: Android 6.0 (API 23)
- **Hedef SDK**: Android 14.0 (API 34)
- **Programlama Dili**: Kotlin 1.9.0
- **Veritabanı**: Room Database
- **Ağ İletişimi**: Retrofit + OkHttp
- **Bağımlılık Enjeksiyonu**: Hilt
- **Arka Plan İşlemleri**: WorkManager

### Performans Optimizasyonları
- **Bellek Yönetimi** (Büyük dosyalar için)
- **Pil Optimizasyonu** (Doze modu uyumluluğu)
- **Ağ Verimliliği** (Bağlantı havuzu)
- **Depolama Optimizasyonu** (Akıllı önbellekleme)

## Kurulum

### Gereksinimler
- Android Studio Arctic Fox (2020.3.1) veya üzeri
- Android SDK 34
- JDK 11 veya üzeri
- Minimum 4GB RAM (Önerilen 8GB)

### Adım Adım Kurulum

1. **Projeyi Klonlayın**
   ```bash
   git clone https://github.com/yourusername/ultra-download-manager.git
   cd ultra-download-manager
   ```

2. **Android Studio'da Açın**
   - Android Studio'yu açın
   - "Open an Existing Project" seçin
   - Proje klasörünü seçin

3. **Bağımlılıkları Senkronize Edin**
   - Android Studio otomatik olarak Gradle senkronizasyonunu başlatacak
   - Veya "Sync Now" butonuna tıklayın

4. **API Anahtarlarını Yapılandırın** (İsteğe bağlı)
   - `local.properties` dosyasına gerekli API anahtarlarını ekleyin

5. **Uygulamayı Derleyin ve Çalıştırın**
   - Run butonuna tıklayın veya `Shift+F10`
   - Bir emülatör veya fiziksel cihaz seçin

### Proje Yapısı

```
ultra-download-manager/
├── app/src/main/java/com/ultra/downloadmanager/
│   ├── ui/                 # Kullanıcı arayüzü bileşenleri
│   │   ├── activities/     # Aktiviteler
│   │   ├── fragments/      # Fragmentlar
│   │   ├── adapters/       # RecyclerView adaptörleri
│   │   └── viewmodels/     # ViewModel'lar
│   ├── data/               # Veri katmanı
│   │   ├── database/       # Room veritabanı
│   │   ├── repository/     # Repository'ler
│   │   └── models/         # Veri modelleri
│   ├── services/           # Android servisleri
│   ├── utils/              # Yardımcı sınıflar
│   └── UltraDownloadManagerApplication.kt
├── app/src/main/res/       # Android kaynakları
├── app/src/main/AndroidManifest.xml
├── build.gradle           # Proje düzeyi Gradle dosyası
└── app/build.gradle       # Uygulama düzeyi Gradle dosyası
```

## Kullanım

### Temel İndirme İşlemi
1. Uygulamayı açın
2. "+" butonuna tıklayarak indirme URL'sini girin
3. İndirme ayarlarını yapılandırın (bağlantı sayısı, öncelik vb.)
4. "İndir" butonuna tıklayın

### Toplu İndirme
1. Ana menüden "Toplu İndirme" seçeneğini seçin
2. Birden fazla URL yapıştırın veya içe aktarın
3. İndirme sırasını ve ayarlarını yapılandırın
4. "Başlat" butonuna tıklayın

### Tarayıcı Entegrasyonu
1. Herhangi bir web tarayıcısında indirmek istediğiniz dosyaya uzun basın
2. "Ultra Download Manager ile İndir" seçeneğini seçin
3. İndirme otomatik olarak başlayacak

## Geliştirme

### Kod Stili
- Kotlin Coding Conventions takip edilmelidir
- Clean Architecture prensiplerine uyulmalıdır
- SOLID prensipleri uygulanmalıdır

### Test
- Unit test'ler `app/src/test/` klasöründe bulunur
- Instrumentation test'ler `app/src/androidTest/` klasöründe bulunur
- Test coverage hedefi: %80+

### Hata Ayıklama
- Logcat kullanarak hata ayıklama yapılabilir
- Debug modda çalıştırarak breakpoint'ler kullanılabilir
- Network Inspector ile ağ istekleri izlenebilir

## Katkıda Bulunma

1. Fork yapın
2. Feature branch oluşturun (`git checkout -b feature/AmazingFeature`)
3. Commit yapın (`git commit -m 'Add some AmazingFeature'`)
4. Branch'inize push yapın (`git push origin feature/AmazingFeature`)
5. Pull Request açın

## Lisans

Bu proje MIT Lisansı ile lisanslanmıştır. Daha fazla bilgi için `LICENSE` dosyasına bakın.

## İletişim

- Email: support@ultra-download-manager.com
- Web: https://ultra-download-manager.com
- GitHub Issues: https://github.com/yourusername/ultra-download-manager/issues

## Sürüm Notları

### v1.0.0 (İlk Sürüm)
- Temel indirme yöneticisi özellikleri
- Çoklu bağlantı desteği
- Kaldığı yerden devam etme
- Modern kullanıcı arayüzü
- Temel dosya yönetimi

---

**Ultra Download Manager** - İndirme deneyimini yeniden tanımlıyor.