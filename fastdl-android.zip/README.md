FastDL Android - fixed package with Gradle wrapper

This package includes:
- app/src/main/AndroidManifest.xml
- app/src/main/java/com/example/fastdownloader/MainActivity.kt
- gradlew (Unix shell wrapper)
- gradlew.bat (Windows wrapper)
- gradle/wrapper/gradle-wrapper.properties
- gradle/wrapper/gradle-wrapper.jar (placeholder)

NOTE: gradle-wrapper.jar is a placeholder. In a CI environment the Gradle wrapper will attempt to download the required Gradle distribution when run. If the CI run fails because of wrapper JAR issues, tell me and I will adjust the workflow to download the wrapper JAR or provide a proper one.
