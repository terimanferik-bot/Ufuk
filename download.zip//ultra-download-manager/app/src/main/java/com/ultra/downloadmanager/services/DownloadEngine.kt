package com.ultra.downloadmanager.services

import android.content.Context
import android.util.Log
import com.ultra.downloadmanager.data.models.DownloadItem
import com.ultra.downloadmanager.data.models.DownloadStatus
import com.ultra.downloadmanager.utils.NetworkUtils
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.*
import java.net.HttpURLConnection
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DownloadEngine @Inject constructor(
    private val context: Context,
    private val okHttpClient: OkHttpClient,
    private val networkUtils: NetworkUtils
) {
    
    private val _activeDownloads = MutableStateFlow<Map<Long, Job>>(emptyMap())
    val activeDownloads: StateFlow<Map<Long, Job>> = _activeDownloads
    
    private val downloadProgressMap = ConcurrentHashMap<Long, DownloadProgress>()
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    
    private data class DownloadProgress(
        var downloadedBytes: Long,
        var totalBytes: Long,
        var speed: Long,
        var lastUpdateTime: Long
    )
    
    suspend fun startDownload(downloadItem: DownloadItem): Boolean {
        return try {
            if (!networkUtils.isNetworkAvailable()) {
                Log.e("DownloadEngine", "Network not available")
                return false
            }
            
            if (_activeDownloads.value.containsKey(downloadItem.id)) {
                Log.w("DownloadEngine", "Download already active: ${downloadItem.id}")
                return false
            }
            
            val job = scope.launch {
                performDownload(downloadItem)
            }
            
            _activeDownloads.value = _activeDownloads.value + (downloadItem.id to job)
            true
        } catch (e: Exception) {
            Log.e("DownloadEngine", "Failed to start download: ${e.message}")
            false
        }
    }
    
    suspend fun pauseDownload(downloadId: Long) {
        _activeDownloads.value[downloadId]?.cancel()
        _activeDownloads.value = _activeDownloads.value - downloadId
        downloadProgressMap.remove(downloadId)
    }
    
    suspend fun resumeDownload(downloadItem: DownloadItem): Boolean {
        return startDownload(downloadItem)
    }
    
    suspend fun cancelDownload(downloadId: Long) {
        pauseDownload(downloadId)
        // Clean up partial files if needed
    }
    
    private suspend fun performDownload(downloadItem: DownloadItem) {
        try {
            val file = File(downloadItem.filePath)
            val fileSize = getFileSize(downloadItem.url, downloadItem.headers)
            
            if (fileSize <= 0) {
                Log.e("DownloadEngine", "Invalid file size: $fileSize")
                return
            }
            
            downloadProgressMap[downloadItem.id] = DownloadProgress(
                downloadedBytes = downloadItem.downloadedBytes,
                totalBytes = fileSize,
                speed = 0,
                lastUpdateTime = System.currentTimeMillis()
            )
            
            if (downloadItem.connectionCount > 1 && fileSize > 1024 * 1024) { // > 1MB
                performMultiConnectionDownload(downloadItem, file, fileSize)
            } else {
                performSingleConnectionDownload(downloadItem, file, fileSize)
            }
            
        } catch (e: Exception) {
            Log.e("DownloadEngine", "Download failed: ${e.message}")
            // Update download status to failed
        } finally {
            _activeDownloads.value = _activeDownloads.value - downloadItem.id
            downloadProgressMap.remove(downloadItem.id)
        }
    }
    
    private suspend fun performSingleConnectionDownload(
        downloadItem: DownloadItem,
        file: File,
        fileSize: Long
    ) {
        withContext(Dispatchers.IO) {
            try {
                val request = Request.Builder()
                    .url(downloadItem.url)
                    .apply {
                        if (downloadItem.downloadedBytes > 0) {
                            addHeader("Range", "bytes=${downloadItem.downloadedBytes}-")
                        }
                        downloadItem.headers.forEach { (key, value) ->
                            addHeader(key, value)
                        }
                    }
                    .build()
                
                okHttpClient.newCall(request).execute().use { response ->
                    if (!response.isSuccessful && response.code != HttpURLConnection.HTTP_PARTIAL) {
                        throw IOException("HTTP error: ${response.code}")
                    }
                    
                    val inputStream = response.body?.byteStream() ?: throw IOException("No response body")
                    val outputStream = FileOutputStream(file, downloadItem.downloadedBytes > 0)
                    
                    val buffer = ByteArray(8192)
                    var bytesRead: Int
                    var totalRead = downloadItem.downloadedBytes
                    var lastSpeedUpdate = System.currentTimeMillis()
                    var bytesSinceLastUpdate = 0L
                    
                    while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                        if (!isActive) {
                            throw CancellationException("Download cancelled")
                        }
                        
                        outputStream.write(buffer, 0, bytesRead)
                        totalRead += bytesRead
                        bytesSinceLastUpdate += bytesRead
                        
                        val currentTime = System.currentTimeMillis()
                        if (currentTime - lastSpeedUpdate >= 1000) { // Update speed every second
                            val speed = bytesSinceLastUpdate * 1000 / (currentTime - lastSpeedUpdate)
                            updateProgress(downloadItem.id, totalRead, speed)
                            bytesSinceLastUpdate = 0
                            lastSpeedUpdate = currentTime
                        }
                    }
                    
                    outputStream.flush()
                    Log.d("DownloadEngine", "Download completed: ${downloadItem.fileName}")
                }
            } catch (e: Exception) {
                Log.e("DownloadEngine", "Single connection download failed: ${e.message}")
                throw e
            }
        }
    }
    
    private suspend fun performMultiConnectionDownload(
        downloadItem: DownloadItem,
        file: File,
        fileSize: Long
    ) {
        val chunkSize = fileSize / downloadItem.connectionCount
        val chunks = mutableListOf<ChunkInfo>()
        
        // Create chunks
        for (i in 0 until downloadItem.connectionCount) {
            val startByte = i * chunkSize + if (i == 0) downloadItem.downloadedBytes else 0
            val endByte = if (i == downloadItem.connectionCount - 1) {
                fileSize - 1
            } else {
                (i + 1) * chunkSize - 1
            }
            
            chunks.add(ChunkInfo(i, startByte, endByte, 0))
        }
        
        // Download chunks concurrently
        coroutineScope {
            chunks.map { chunk ->
                async {
                    downloadChunk(downloadItem, file, chunk)
                }
            }.awaitAll()
        }
    }
    
    private suspend fun downloadChunk(
        downloadItem: DownloadItem,
        file: File,
        chunk: ChunkInfo
    ) {
        withContext(Dispatchers.IO) {
            try {
                val request = Request.Builder()
                    .url(downloadItem.url)
                    .header("Range", "bytes=${chunk.startByte + chunk.downloadedBytes}-${chunk.endByte}")
                    .apply {
                        downloadItem.headers.forEach { (key, value) ->
                            addHeader(key, value)
                        }
                    }
                    .build()
                
                okHttpClient.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        throw IOException("HTTP error: ${response.code}")
                    }
                    
                    val inputStream = response.body?.byteStream() ?: throw IOException("No response body")
                    val accessFile = RandomAccessFile(file, "rw")
                    
                    try {
                        accessFile.seek(chunk.startByte + chunk.downloadedBytes)
                        
                        val buffer = ByteArray(8192)
                        var bytesRead: Int
                        var chunkBytesRead = chunk.downloadedBytes
                        
                        while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                            if (!isActive) {
                                throw CancellationException("Download cancelled")
                            }
                            
                            accessFile.write(buffer, 0, bytesRead)
                            chunkBytesRead += bytesRead
                            
                            synchronized(downloadProgressMap) {
                                downloadProgressMap[downloadItem.id]?.let { progress ->
                                    progress.downloadedBytes += bytesRead
                                }
                            }
                        }
                    } finally {
                        accessFile.close()
                    }
                }
            } catch (e: Exception) {
                Log.e("DownloadEngine", "Chunk download failed: ${e.message}")
                throw e
            }
        }
    }
    
    private suspend fun getFileSize(url: String, headers: Map<String, String>): Long {
        return withContext(Dispatchers.IO) {
            try {
                val request = Request.Builder()
                    .url(url)
                    .head()
                    .apply {
                        headers.forEach { (key, value) ->
                            addHeader(key, value)
                        }
                    }
                    .build()
                
                okHttpClient.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        response.headers["Content-Length"]?.toLongOrNull() ?: -1L
                    } else {
                        -1L
                    }
                }
            } catch (e: Exception) {
                Log.e("DownloadEngine", "Failed to get file size: ${e.message}")
                -1L
            }
        }
    }
    
    private fun updateProgress(downloadId: Long, downloadedBytes: Long, speed: Long) {
        // Notify UI about progress update
        // This would typically be done through a Flow or LiveData
        Log.d("DownloadEngine", "Progress update - ID: $downloadId, Bytes: $downloadedBytes, Speed: $speed")
    }
    
    private data class ChunkInfo(
        val id: Int,
        val startByte: Long,
        val endByte: Long,
        var downloadedBytes: Long
    )
}