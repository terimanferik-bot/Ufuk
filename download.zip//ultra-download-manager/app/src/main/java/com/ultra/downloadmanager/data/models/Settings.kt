package com.ultra.downloadmanager.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "settings")
data class Settings(
    @PrimaryKey
    val key: String,
    val value: String,
    val description: String? = null
)

data class AppSettings(
    val maxConcurrentDownloads: Int = 5,
    val maxConnectionsPerDownload: Int = 8,
    val defaultDownloadPath: String = "/storage/emulated/0/Download/UltraDM",
    val enableAutoResume: Boolean = true,
    val enableSmartRetry: Boolean = true,
    val enableNotifications: Boolean = true,
    val enableSoundNotifications: Boolean = false,
    val enableVibration: Boolean = true,
    val theme: AppTheme = AppTheme.SYSTEM,
    val language: String = "en",
    val speedLimit: Long = 0, // 0 means unlimited
    val enableBatteryOptimization: Boolean = true,
    val enableWiFiOnly: Boolean = false,
    val enableAutoCategorization: Boolean = true,
    val enableDuplicateDetection: Boolean = true,
    val enableClipboardMonitoring: Boolean = true,
    val enableBrowserIntegration: Boolean = true,
    val downloadTimeout: Int = 30000, // milliseconds
    val readTimeout: Int = 15000, // milliseconds
    val userAgent: String = "UltraDownloadManager/1.0",
    val enableCompression: Boolean = true,
    val enableEncryption: Boolean = false,
    val enableMediaProcessing: Boolean = true
)

enum class AppTheme {
    LIGHT,
    DARK,
    SYSTEM
}